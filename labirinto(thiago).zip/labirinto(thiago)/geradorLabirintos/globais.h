#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXLINE 1000
#define DELIM	" "
#define MAXCEL 65

