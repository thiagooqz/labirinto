/*
    Autor: Thiago Queiroz da Silva
    Objetivo: Implementação de uma estratégia de busca.
*/

// ***  FUNÇÕES DE INICIALIZAÇÃO E EXECUÇÃO DO JOGADOR 1 ***
// Implementação da estratégia: BUSCA EM PROFUNDIDADE.
int player1_Reticulado[MAXCEL][MAXCEL];
tipo_PosicaoPlano player1_Coord;
std::vector<const char *> player1_PilhaHistorico;

void init_Player1() {
    // Inicializa reticulado com valor negativo,
    // que indica que o jogador ainda não passou pela sala.
    for(int y=0; y<MAXCEL; y++) {
        for(int x=0; x<MAXCEL; x++) {
            player1_Reticulado[y][x]= -1;
        }
    }

    // Desmonta a pilha.
    while (player1_PilhaHistorico.size() > 0) {
        player1_PilhaHistorico.pop_back();
    }

    // Registra posição atual do jogador.
    player1_Coord.x = posAtualP1.x;
    player1_Coord.y = posAtualP1.y;
}

const char *run_Player1() {
    const char *movimento = "null";

    // Verifica se a sala ainda não foi visitada.
    if (player1_Reticulado[player1_Coord.x][player1_Coord.y] == -1) {
        const char *origem = "null";
        // Verifica o caminho de origem.
        if (player1_PilhaHistorico.size() > 0) {
            origem = player1_PilhaHistorico[player1_PilhaHistorico.size()-1];
        }

        // Verifica novos caminhos, ignorando origem.
        player1_Reticulado[player1_Coord.x][player1_Coord.y] = 0;
        for (int c=0; c<NUMCAMINHOS; c++) {
            if ((strcmp(origem, id_Caminhos[c])) && (maze_VerCaminho(id_Caminhos[c]) == CAMINHO)) {
                player1_Reticulado[player1_Coord.x][player1_Coord.y] += pow(2,c);
            }
        }
    }

    // Enquanto houver opções de seguir em frente, escolha uma aleatoriamente.
    if (player1_Reticulado[player1_Coord.x][player1_Coord.y] > 0) {
        // Verifique quais caminhos estão abertos.
        int vet_Caminhos[NUMCAMINHOS];
        int count_Aux = 0;
        for (int c=0; c<NUMCAMINHOS; c++) {
            // bits: 1 Norte / 2 Sul / 4 Oeste / 8 Leste
            unsigned int mask = pow(2,c);
            if ((player1_Reticulado[player1_Coord.x][player1_Coord.y] & mask) == mask) {
                vet_Caminhos[count_Aux] = c;
                count_Aux++;
            }
        }
        int escolha = vet_Caminhos[rand()%count_Aux];

        // Grava movimento.
        movimento = id_Caminhos[escolha];

        // Fecha caminho escolhido.
        player1_Reticulado[player1_Coord.x][player1_Coord.y] -= pow(2,escolha);

        // Atualiza posição atual.
        if (escolha == 0) player1_Coord.y--;
        else if (escolha == 1) player1_Coord.y++;
        else if (escolha == 2) player1_Coord.x--;
        else if (escolha == 3) player1_Coord.x++;

        // Empilha movimento de retorno.
        player1_PilhaHistorico.push_back(id_Retornos[escolha]);
    }
    else {
        // Se não houver opção de prosseguir, verifica retorno no caminho.
        movimento = player1_PilhaHistorico[player1_PilhaHistorico.size()-1];

        // Atualiza coordenada com base no movimento de retorno.
        if (!strcmp(movimento, "norte")) {
            player1_Coord.y--;
        }
        if (!strcmp(movimento, "sul")) {
            player1_Coord.y++;
        }
        if (!strcmp(movimento, "oeste")) {
            player1_Coord.x--;
        }
        if (!strcmp(movimento, "leste")) {
            player1_Coord.x++;
        }

        // Desempilha.
        player1_PilhaHistorico.pop_back();
    }

    return movimento;
}

// ***  FUNÇÕES DE INICIALIZAÇÃO E EXECUÇÃO DO JOGADOR 2 ***
// Implementação da segunda estratégia: BUSCA EM PROFUNDIDADE.
int player2_Reticulado[MAXCEL][MAXCEL];
tipo_PosicaoPlano player2_Coord;
std::vector<const char *> player2_PilhaHistorico;

void init_Player2() {
    // Inicializa reticulado com valor negativo,
    // que indica que o jogador ainda não passou pela sala.
    for(int y=0; y<MAXCEL; y++) {
        for(int x=0; x<MAXCEL; x++) {
            player2_Reticulado[y][x]= -1;
        }
    }

    // Desmonta a pilha.
    while (player2_PilhaHistorico.size() > 0) {
        player2_PilhaHistorico.pop_back();
    }

    // Registra posição atual do jogador.
    player2_Coord.x = posAtualP2.x;
    player2_Coord.y = posAtualP2.y;
}

const char *run_Player2() {
    const char *movimento = "null";

    // Verifica se a sala ainda não foi visitada.
    if (player2_Reticulado[player2_Coord.x][player2_Coord.y] == -1) {
        const char *origem = "null";
        // Verifica o caminho de origem.
        if (player2_PilhaHistorico.size() > 0) {
            origem = player2_PilhaHistorico[player2_PilhaHistorico.size()-1];
        }

        // Verifica novos caminhos, ignorando origem.
        player2_Reticulado[player2_Coord.x][player2_Coord.y] = 0;
        for (int c=0; c<NUMCAMINHOS; c++) {
            if ((strcmp(origem, id_Caminhos[c])) && (maze_VerCaminho(id_Caminhos[c]) == CAMINHO)) {
                player2_Reticulado[player2_Coord.x][player2_Coord.y] += pow(2,c);
            }
        }
    }

    // Enquanto houver opções de seguir em frente, escolha uma aleatoriamente.
    if (player2_Reticulado[player2_Coord.x][player2_Coord.y] > 0) {
        // Verifique quais caminhos estão abertos.
        int vet_Caminhos[NUMCAMINHOS];
        int count_Aux = 0;
        for (int c=0; c<NUMCAMINHOS; c++) {
            // bits: 1 Norte / 2 Sul / 4 Oeste / 8 Leste
            unsigned int mask = pow(2,c);
            if ((player2_Reticulado[player2_Coord.x][player2_Coord.y] & mask) == mask) {
                vet_Caminhos[count_Aux] = c;
                count_Aux++;
            }
        }
        int escolha = vet_Caminhos[rand()%count_Aux];

        // Grava movimento.
        movimento = id_Caminhos[escolha];

        // Fecha caminho escolhido.
        player2_Reticulado[player2_Coord.x][player2_Coord.y] -= pow(2,escolha);

        // Atualiza posição atual.
        if (escolha == 0) player2_Coord.y--;
        else if (escolha == 1) player2_Coord.y++;
        else if (escolha == 2) player2_Coord.x--;
        else if (escolha == 3) player2_Coord.x++;

        // Empilha movimento de retorno.
        player2_PilhaHistorico.push_back(id_Retornos[escolha]);
    }
    else {
        // Se não houver opção de prosseguir, verifica retorno no caminho.
        movimento = player2_PilhaHistorico[player2_PilhaHistorico.size()-1];

        // Atualiza coordenada com base no movimento de retorno.
        if (!strcmp(movimento, "norte")) {
            player2_Coord.y--;
        }
        if (!strcmp(movimento, "sul")) {
            player2_Coord.y++;
        }
        if (!strcmp(movimento, "oeste")) {
            player2_Coord.x--;
        }
        if (!strcmp(movimento, "leste")) {
            player2_Coord.x++;
        }

        // Desempilha.
        player2_PilhaHistorico.pop_back();
    }

    return movimento;
}
